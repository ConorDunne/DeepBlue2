/*
    17379526    Conor Dunne
    17424866    Martynas Jagutis
    17379773    Ronan Mascarenhas
*/

package src.Objects;

public enum moveType {
    BearOff,   //  Dice 1 Bears off counter
    Normal,    //  Dice 1 Moves counter
    Hit,  //  Dice 1 Knocks off counter
    NotValid    //  No moves possible
}
